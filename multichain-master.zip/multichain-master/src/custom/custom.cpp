// Copyright (c) 2014-2019 Coin Sciences Ltd
// MultiChain code distributed under the GPLv3 license, see COPYING file.

#include "custom/custom.h"

using namespace std;

int custom_version_info(int version)
{
    return 0;
}

void custom_set_runtime_defaults(int exe_type)
{
    
}



