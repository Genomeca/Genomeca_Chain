// Copyright (c) 2013 The Bitcoin developers
// Original code was distributed under the MIT/X11 software license.
// Copyright (c) 2014-2019 Coin Sciences Ltd
// MultiChain code distributed under the GPLv3 license, see COPYING file.

#ifndef BITCOIN_NOUI_H
#define BITCOIN_NOUI_H

extern void noui_connect();

#endif // BITCOIN_NOUI_H
